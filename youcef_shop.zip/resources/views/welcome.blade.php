@extends('layouts.app')

@section('title')
 Accueil
@endsection

@section('header')
 <style type="text/css">
       .header__menu ul li.home a {
    color: #007bff;
}
 </style>
@endsection

@section('content')

     <section class="categories" style="margin-bottom: 0px">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                    @foreach(All_Sous_Category() as $souscategory)
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" >
                            <img src="{{asset('/souscategory/'.$souscategory->image)}}" style="height: 180px;">
                            <h5><a href="{{url('/all-product-in-sub-category/'.$souscategory->id.'/'.$souscategory->souscategory)}}">{{$souscategory->souscategory}}</a></h5>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
 
  <section class="featured spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Dernier Marques Ajoutées</h2>
                    </div>
                    <div class="featured__controls">
                        <ul>
                            <li class="active" data-filter="*">Tout</li>
                            @foreach(get_Last_marque() as $marque)
                            <li data-filter=".{{$marque->marque}}">{{$marque->marque}}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row featured__filter">
                @foreach(All_Product() as $product)
                <div class="col-lg-3 col-md-4 col-sm-6 mix {{$product->marque}} fresh-meat">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="{{asset('/product/'.$product->image_principale)}}">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#">{{$product->name}}</a></h6>
                            <h5>{{$product->prix}}</h5>
                        </div>
                    </div>
                </div>
                @endforeach
               
                
            </div>
        </div>
    </section>

    <div class="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6" >
                    <section class="hero">
                    <div class="hero__item set-bg" data-setbg="/designe/img/img1.jpg" style="height: 270px">
                        <div  class="hero__text">
                            <h4 style="margin-bottom: 0px;margin-top: 0px;font-weight: bold; color: white">Nous Proposons Plein De Services De Vente Pour Vous </h4>
                            <a href="{{url('/about')}}" class="btn btn-success">Decouvrez Nos Services</a>
                        </div>
                    </div>
                </section>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                   <section class="hero">
                    <div class="hero__item set-bg" data-setbg="/designe/img/img3.jpg" style="height: 270px">
                        <div  class="hero__text">
                            <h1 style="font-weight: bold;color: #17a2b8;font-family: italic">{{getsetting()->site_name}}</h1>
                            <h4 style="margin-bottom: 0px;margin-top: 0px;font-weight: bold; color: black;color: white">Votre Solution Pour L'achat En Ligne</h4>
                            <a href="{{url('/all-products')}}" class="btn btn-success">Voir Nos Produits</a>
                        </div>
                    </div>
                    
                </section>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->

    <!-- Latest Product Section Begin -->
    <section class="latest-product spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Nouveaux Produits</h4>
                        <div class="latest-product__slider owl-carousel">
                            <div class="latest-prdouct__slider__item">
                                @foreach(New_Product() as $product)
                                        <a href="{{url('/show-products/'.$product->id.'/'.$product->marque)}}" class="latest-product__item">
                                            <div class="latest-product__item__pic">
                                                <img src="{{asset('/product/'.$product->image_principale)}}" alt="{{$product->name}}" style="width: 95px">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6>{{$product->name}}</h6>
                                                <span>{{$product->prix}}</span>
                                            </div>
                                        </a>
                                        @endforeach
                            </div>
                           
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Les plus Produits visites</h4>
                        <div class="latest-product__slider owl-carousel">
                            <div class="latest-prdouct__slider__item">
                                @foreach(Favorate_Product() as $product)
                                        <a href="{{url('/show-products/'.$product->id.'/'.$product->marque)}}" class="latest-product__item">
                                            <div class="latest-product__item__pic">
                                                <img src="{{asset('/product/'.$product->image_principale)}}" alt="{{$product->name}}" style="width: 95px">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6>{{$product->name}}</h6>
                                                <span>{{$product->prix}}</span>
                                                <span style="color: red;font-size: 12px">({{$product->view}} vues)</span>
                                            </div>
                                        </a>
                                        @endforeach
                            </div>
                           
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="latest-product__text">
                        <h4>Les plus Produits ventes</h4>
                        <div class="latest-product__slider owl-carousel">
                           
                            <div class="latest-prdouct__slider__item">
                                @foreach(Favorate_Product_Vente() as $product)
                                        <a href="{{url('/show-products/'.$product->id.'/'.$product->marque)}}" class="latest-product__item">
                                            <div class="latest-product__item__pic">
                                                <img src="{{asset('/product/'.$product->image_principale)}}" alt="{{$product->name}}" style="width: 95px">
                                            </div>
                                            <div class="latest-product__item__text">
                                                <h6>{{$product->name}}</h6>
                                                <span>{{$product->prix}}</span>
                                                <span style="color: red;font-size: 12px">({{$product->vente}} ventes)</span>
                                            </div>
                                        </a>
                                        @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Latest Product Section End -->

    <!-- Blog Section Begin -->
    <!--section class="from-blog spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title from-blog__title">
                        <h2>From The Blog</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="blog__item">
                        <div class="blog__item__pic">
                            <img src="/designe/img/blog/blog-1.jpg" alt="">
                        </div>
                        <div class="blog__item__text">
                            <ul>
                                <li><i class="fa fa-calendar-o"></i> May 4,2019</li>
                                <li><i class="fa fa-comment-o"></i> 5</li>
                            </ul>
                            <h5><a href="#">Cooking tips make cooking simple</a></h5>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="blog__item">
                        <div class="blog__item__pic">
                            <img src="/designe/img/blog/blog-2.jpg" alt="">
                        </div>
                        <div class="blog__item__text">
                            <ul>
                                <li><i class="fa fa-calendar-o"></i> May 4,2019</li>
                                <li><i class="fa fa-comment-o"></i> 5</li>
                            </ul>
                            <h5><a href="#">6 ways to prepare breakfast for 30</a></h5>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="blog__item">
                        <div class="blog__item__pic">
                            <img src="/designe/img/blog/blog-3.jpg" alt="">
                        </div>
                        <div class="blog__item__text">
                            <ul>
                                <li><i class="fa fa-calendar-o"></i> May 4,2019</li>
                                <li><i class="fa fa-comment-o"></i> 5</li>
                            </ul>
                            <h5><a href="#">Visit the clean farm in the US</a></h5>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section-->
@endsection

@section('footer')
 
@endsection