<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="youcef-shop">
    <meta name="keywords" content="youcef-shop">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="shortcut icon" href="{{asset('/images/'.getsetting()->logo)}}" type="image/x-icon" />

    <title>{{getsetting()->site_name}} | @yield('title')</title>

    <!-- Scripts -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">
   <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    {!!Html::style('/designe/css/bootstrap.min.css')!!}
    {!!Html::style('/designe/css/font-awesome.min.css')!!}
    {!!Html::style('/designe/css/elegant-icons.css')!!}
    {!!Html::style('/designe/css/nice-select.css')!!}
    {!!Html::style('/designe/css/jquery-ui.min.css')!!}
    {!!Html::style('/designe/css/owl.carousel.min.css')!!}
    {!!Html::style('/designe/css/slicknav.min.css')!!}
    {!!Html::style('/designe/css/style.css')!!}
    @yield('header')

</head>
<body>
    
 <div id="preloder">
        <div class="loader"></div>
    </div>
    <div class="humberger__menu__overlay"></div>
  <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="{{url('/home')}}"><img src="{{asset('/images/'.getsetting()->logo)}}" alt="{{getsetting()->site_name}}"></a>
        </div>
        <div class="humberger__menu__cart">
            <ul>
                <li><a href="{{url('/cart')}}"><i class="fa fa-shopping-bag"></i> <span>{{Cart::count()}}</span></a></li>
            </ul>
            <div class="header__cart__price">TOTAL: <span>{{Cart::subtotal()}} DA</span></div>
        </div>
        <div class="humberger__menu__widget">
            <!--div class="header__top__right__language">
                <img src="/designe/img/language.png" alt="">
                 <div>Français</div>
                 <span class="fa fa-angle-down"></span>
                 <ul>
                     <li><a href="#">Arabe</a></li>
                     <li><a href="#">Français</a></li>
                 </ul>
            </div-->
            <div class="header__top__right__auth">
                <a href="{{ route('login') }}"><i class="fa fa-user"></i> SE CONNECTER</a>
            </div>
        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li class="home"><a href="{{url('/home')}}">ACCUEIL</a></li>
                <li class="product"><a href="{{url('/all-products')}}">PRODUITS</a></li>
                <li class="about"><a href="{{url('/about')}}">QUI SOMMES NOUS</a></li>
                <li class="contact"><a href="{{url('/contact')}}">CONTACTER NOUS</a></li>

            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="header__top__right__social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
        </div>
        <div class="humberger__menu__contact">
            <ul>
                <li><i class="fa fa-envelope" style="color: white"></i> {{getsetting()->site_email}}</li>
                <li>{{getsetting()->slegon}}</li>
            </ul>
        </div>
    </div>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__left">
                            <ul>
                                <li><i class="fa fa-envelope" style="color: white"></i>{{getsetting()->site_email}}</li>
                                <li>{{getsetting()->slegon}}</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="header__top__right">
                            <div class="header__top__right__social">
                                <a href="#"><i class="fa fa-facebook" style="color: white"></i></a>
                                <a href="#"><i class="fa fa-twitter" style="color: white"></i></a>
                                <a href="#"><i class="fa fa-linkedin" style="color: white"></i></a>
                                <a href="#"><i class="fa fa-instagram" style="color: white"></i></a>
                            </div>
                            <!--div class="header__top__right__language">
                                <img src="/designe/img/language.png" alt="">
                                <div style="color: white">Français</div>
                                <span class="fa fa-angle-down" style="color: white"></span>
                                <ul>
                                    <li><a href="#" style="color: white">Arabe</a></li>
                                    <li><a href="#" style="color: white">Français</a></li>
                                </ul>
                            </div-->
                            
                            <div class="header__top__right__auth">
                                <a href="{{ route('login') }}" style="color: white"><i class="fa fa-user" style="color: white"></i> SE CONECTER</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="{{url('/home')}}"><img src="{{asset('/images/'.getsetting()->logo)}}" alt="{{getsetting()->site_name}}"></a>
                    </div>
                </div>
                <div class="col-lg-7">
                    <nav class="header__menu">
                        <ul>
                <li class="active"><a href="{{url('/home')}}">ACCUEIL</a></li>
                <li><a href="{{url('/all-products')}}">PRODUITS</a></li>
                <li><a href="{{url('/about')}}">QUI SOMMES NOUS</a></li>
                <li><a href="{{url('/contact')}}">CONTACTER NOUS</a></li>

            </ul>
                    </nav>
                </div>
                <div class="col-lg-2">
                    <div class="header__cart">
                        <ul>
                            <li><a href="{{url('/cart')}}"><i class="fa fa-shopping-bag"></i> <span>{{Cart::count()}}</span></a></li>
                        </ul>
                        <div class="header__cart__price">TOTAL: <span>{{Cart::subtotal()}} DA</span></div>
                    </div>
                </div>
            </div>
            <div class="humberger__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
@if($_SERVER['REQUEST_URI'] == '/home' || $_SERVER['REQUEST_URI'] == '/')
  <section class="hero">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="hero__categories">
                        <div class="hero__categories__all">
                            <i class="fa fa-bars"></i>
                            <span>CATEGORIES&thinsp;&thinsp;&thinsp;<span class="fa fa-angle-down"></span></span>
                        </div>
                        <ul>
                            @foreach(All_Category() as $category)
                            <li><a href="{{url('/all-products/'.$category->id.'/'.$category->category)}}">{{$category->category}}</a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form action="{{url('/global-search')}}" method="get"> 
                                <input type="text" placeholder="Rechercher votre produit" name="product">
                                <button type="submit" class="site-btn" style="border-radius:20px 0px 0px 20px">RECHERCHE</button>
                            </form>
                        </div>
                        <div class="hero__search__phone">
                            <div class="hero__search__phone__icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="hero__search__phone__text">
                                <h5>+213{{getsetting()->site_phone}}</h5>
                                <span>support 24/7 time</span>
                            </div>
                        </div>
                    </div>
                  
                    <div class="hero__item set-bg" data-setbg="{{asset('/images/'.getsetting()->welcome_photo)}}">
                        <div  class="hero__text">
                            <h1 style="font-size: 20px;font-weight: bold;color: blue">{{getsetting()->site_name}}</h1>
                            <h2>Livraison <br />48 Wilaya <br> Plus de 10000 DA</h2>
                            <p >Demandez votre produit maintenant</p>
                            <a href="{{url('/all-products')}}" class="btn btn-primary">Achetez maintenant</a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
@endif

@yield('content')


     <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="{{url('/home')}}"><img src="{{asset('/images/'.getsetting()->logo)}}" alt="{{getsetting()->site_name}}"></a>
                        </div>
                        <ul>
                            <li><span class="fa fa-map-marker"></span>  {{getsetting()->adress}}</li>
                            <li><span class="fa fa-phone"></span>   +213{{getsetting()->site_phone}}</li>
                            <li><span class="fa fa-envelope"></span>  {{getsetting()->site_email}}</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
                    <div class="footer__widget">
                        <h6>MENU</h6>
                        <ul>
                            <li><a href="#">Qui sommes nous</a></li>
                            <li><a href="#">Nos services</a></li>
                            <li><a href="#">Nos produits</a></li>
                            <li><a href="#">Contacter nous</a></li>
                        </ul>
                    </div>

                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="footer__widget">
                        <h6>Rejoignez notre newsletter maintenant</h6>
                        <p>Recevez des mises à jour par e-mail sur notre dernière boutique et nos offres spéciales.</p>
                        <form action="#">
                            <input type="text" placeholder="Enter your mail">
                            <button type="submit" class="site-btn">Envoyer</button>
                        </form>
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text text-center"><p class="text-center">
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> Tout droits réservés</p></div>
                        <div class="footer__copyright__payment"><img src="img/payment-item.png" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    {!!Html::script('/designe/js/jquery-3.3.1.min.js')!!}
    {!!Html::script('/designe/js/bootstrap.min.js')!!}
    {!!Html::script('/designe/js/jquery.nice-select.min.js')!!}
    {!!Html::script('/designe/js/jquery-ui.min.js')!!}
    {!!Html::script('/designe/js/jquery.slicknav.js')!!}
    {!!Html::script('/designe/js/mixitup.min.js')!!}
    {!!Html::script('/designe/js/owl.carousel.min.js')!!}
    {!!Html::script('/designe/js/main.js')!!}
    @yield('footer')
</body>
</html>
