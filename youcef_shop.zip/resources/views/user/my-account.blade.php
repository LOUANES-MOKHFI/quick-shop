@extends('layouts.app')

@section('title')
 MON PROFIL
@endsection

@section('header')
 
@endsection

@section('content')

@endsection

@section('footer')
 
@endsection