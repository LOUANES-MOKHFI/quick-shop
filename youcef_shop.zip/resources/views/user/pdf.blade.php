<!DOCTYPE html>
<html>
<head>
	<title>DEVIS</title>

<style type="text/css">
body {
    background: #eee
}
</style>
</head>
<body>
	<div class="container mt-5">
    <div class="d-flex justify-content-center row">
        <div class="col-md-8">
            <div class="p-3 bg-white rounded">
                <div class="row">
                    <div class="col-md-6">
                        <h1 class="text-uppercase">{{getsetting()->site_name}}</h1>
                        <div class="billed"><span class="font-weight-bold text-uppercase">Adress:</span><span class="ml-1">{{getsetting()->adress}}</span></div>
                        <div class="billed"><span class="font-weight-bold text-uppercase">Email:</span><span class="ml-1">{{getsetting()->site_email}}</span></div>
                        <div class="billed"><span class="font-weight-bold text-uppercase">Télèphone:</span><span class="ml-1">{{getsetting()->site_phone}}</span></div>
                    </div>
                    <div class="col-md-6 text-right mt-3">
                        <h4 class="text-danger mb-0">{{$fname}}-{{$lname}}</h4><span>{{$wilaya}}-{{$commune}}-{{$adress}}</span>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                   <th>Produit</th>
								   <th>Quantities</th>
								   <th>Prix Unitaire</th>
								   <th>Prix total</th>
                                </tr>
                            </thead>
                            <tbody>
                        @foreach(Cart::content() as $commande)
                          <tr>
                          	 <td>{{getProduit_commande($commande->id)->name}}</td>
                          	 <td>{{$commande->qty}}</td>
                          	 <td>{{$commande->price}} DA</td>
                          	 <td>{{$commande->qty * $commande->price}} DA</td>
                          </tr>
						@endforeach
                                <tr>
                                    
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>PRIX TOTAL:</td>
                                    <td> {{Cart::subtotal()}} DA</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>