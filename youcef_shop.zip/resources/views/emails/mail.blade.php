Bonjour <strong>{{ $name }}</strong>,
<p>{{$body}}</p>
